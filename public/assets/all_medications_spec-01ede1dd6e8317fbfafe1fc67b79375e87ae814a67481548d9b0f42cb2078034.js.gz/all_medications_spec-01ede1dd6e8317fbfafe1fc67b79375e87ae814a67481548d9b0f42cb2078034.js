describe('our awesome test suite', function () {

  it('should work, right?', function () {
    assert(true);
  });

});
