
MagicLamp.genie.cacheOnly = true;
MagicLamp.genie.cache = {}

