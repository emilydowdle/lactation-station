MagicLamp.initialize();
